package com.capgemini.training.java.jfx.ui;

public class TaskListController {

}
