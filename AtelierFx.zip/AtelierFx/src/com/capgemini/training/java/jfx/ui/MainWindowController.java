package com.capgemini.training.java.jfx.ui;

import java.io.File;
import java.util.Optional;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.stage.FileChooser;

public class MainWindowController {
	@FXML
	private void handleMenuFileOpen(ActionEvent event) {
		FileChooser chooser = new FileChooser();
		File choix = chooser.showOpenDialog(null);
		
		if(choix!=null) {
			//choix.getAbsolutePath()
		}
	}
	@FXML
	private void handleMenuFileQuit(ActionEvent event) {
		Alert alert = new Alert(
				AlertType.CONFIRMATION,
				"Vous �tes s�r de vouloir quitter ?",
				ButtonType.OK,
				ButtonType.CANCEL
		);
		Optional<ButtonType> result = alert.showAndWait();
		
		if(result.isPresent() && result.get() == ButtonType.OK) {
			Platform.exit();
		}
	}
}
